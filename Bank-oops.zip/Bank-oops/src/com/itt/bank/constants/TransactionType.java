package com.itt.bank.constants;

public enum TransactionType {
	
		DEBIT,CREDIT
	
}
