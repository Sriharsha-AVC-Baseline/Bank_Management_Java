package com.itt.constantUtilities;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Utilities {
	
	public static final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

}
