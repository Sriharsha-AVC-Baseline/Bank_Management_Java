package com.itt.exceptions;

public class RecipientNotFoundException extends Exception {

	public RecipientNotFoundException(String message) {
		super(message);
	}
	
}
