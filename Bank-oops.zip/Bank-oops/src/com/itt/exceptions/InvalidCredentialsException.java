package com.itt.exceptions;

public class InvalidCredentialsException extends Exception {
	
	public InvalidCredentialsException() {
		super("Invalid Credentials");
	}

}
